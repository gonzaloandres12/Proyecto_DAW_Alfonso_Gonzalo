const marcas = [
    {
      zapatillas: [
        {
          marca: "Nike",
        },
        {
          marca: "Adidas",
        },
        {
          marca: "Puma",
        },
        {
          marca: "New Balance",
        },
        {
          marca: "Vans",
        },
  
        {
          marca: "Reebok",
        },
        {
          marca: "Converse",
        },
        {
          marca: "Under Armour",
        },
        {
          marca: "Salomon",
        },
        {
          marca: "Fila",
        },
      ],
    },
  ];