const SneaksAPI = require("sneaks-api");
const sneaks = new SneaksAPI();

const marcas = [
  {
    zapatillas: [
      {
        marca: "Nike",
      },
      {
        marca: "Adidas",
      },
      {
        marca: "Puma",
      },
      {
        marca: "New Balance",
      },
      {
        marca: "Vans",
      },
      {
        marca: "Reebok",
      },
      {
        marca: "Converse",
      },
      {
        marca: "Under Armour",
      },
      {
        marca: "Salomon",
      },
      {
        marca: "Fila",
      },
    ],
  },
];

const zapatillas = marcas[0].zapatillas;

// Array para almacenar los resultados
const resultados = [];

zapatillas.forEach((zapatilla) => {
  const marca = zapatilla.marca;

  console.log(`Marca: ${marca}`);
  console.log("---------------------");

  sneaks.getProducts(marca, 15, function (err, products) {
    if (err) {
      console.error(`Error al obtener productos para la marca ${marca}:`, err);
      return;
    }

    const resultadoMarca = {
      marca: marca,
      productos: products,
    };

    resultados.push(resultadoMarca);
    console.log(resultadoMarca);


  });
});

console.log("**********************************"+resultados);
