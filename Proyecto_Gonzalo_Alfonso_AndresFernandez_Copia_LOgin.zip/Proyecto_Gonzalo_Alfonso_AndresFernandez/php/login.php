<?php
// Establecer la conexión a la base de datos (actualiza los valores con los tuyos)
$servername = "localhost";
$username = "root";
$password = "7388";
$dbname = "tienda";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar si hay errores en la conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}   

// Obtener los datos del formulario
$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

// Comprobar si el usuario ya existe en la base de datos
$sql = "SELECT * FROM login WHERE user = '$username'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "El usuario ya existe en la base de datos.";
    // Puedes redirigir al usuario a una página de error o realizar otras acciones necesarias
    exit(); // Detener la ejecución del script
}

// Comprobar si el usuario o la contraseña están vacíos
if (empty($username) || empty($password)) {
    echo "El usuario y la contraseña son campos obligatorios.";
    // Puedes redirigir al usuario a una página de error o realizar otras acciones necesarias
    exit(); // Detener la ejecución del script
}

// Cifrar la contraseña (puedes utilizar diferentes métodos de cifrado, este es solo un ejemplo)
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

// Insertar el nuevo usuario en la base de datos
$sql = "INSERT INTO login (user, password) VALUES ('$username', '$hashedPassword')";

if ($conn->query($sql) === TRUE) {
    echo "Usuario registrado exitosamente!";
} else {
    echo "Error al registrar al usuario: " . $conn->error;
}
$conn->close();
?>



